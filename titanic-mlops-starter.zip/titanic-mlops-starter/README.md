# Titanic MLOps Pipeline (Local, End‑to‑End)

Fully working MLOps starter for binary classification (Survived / Not Survived) on the Titanic dataset.
Covers data prep, experiment tracking with MLflow, API (FastAPI), Docker, CI, and logging to SQLite.

## Quickstart

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python src/prep_data.py --input data/train.csv --output data/titanic_clean.csv
python src/train.py --data data/titanic_clean.csv --registry models
python src/evaluate.py --data data/titanic_clean.csv --model models/model.joblib
uvicorn api.main:app --host 0.0.0.0 --port 8000
curl -X POST "http://localhost:8000/predict" -H "Content-Type: application/json" -d @api/sample.json
```

## MLflow UI
```bash
mlflow ui --host 0.0.0.0 --port 5001
```

## Docker
```bash
docker build -t titanic-api:latest .
docker run -p 8000:8000 titanic-api:latest
```
