Optional Prometheus/Grafana configs can be placed here.
