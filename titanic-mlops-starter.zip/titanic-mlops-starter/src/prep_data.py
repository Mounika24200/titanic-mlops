import argparse
import pandas as pd

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df['Age_missing'] = df['Age'].isna().astype(int)
    df['Age'] = df['Age'].fillna(df['Age'].median())
    if 'Embarked' in df.columns:
        df['Embarked'] = df['Embarked'].fillna(df['Embarked'].mode()[0])
    if 'Fare' in df.columns:
        df['Fare'] = df['Fare'].fillna(df['Fare'].median())
    df['IsChild'] = (df['Age'] < 16).astype(int)
    if 'SibSp' in df.columns and 'Parch' in df.columns:
        df['FamilySize'] = df['SibSp'] + df['Parch'] + 1
    if 'Name' in df.columns:
        df['Title'] = df['Name'].str.extract(r',\s*([^\.]+)\.').fillna('None')
    else:
        df['Title'] = 'None'
    categoricals = [c for c in ['Sex','Embarked','Title'] if c in df.columns]
    df = pd.get_dummies(df, columns=categoricals, drop_first=True)
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    df = pd.read_csv(args.input)
    df_clean = engineer_features(df)
    df_clean.to_csv(args.output, index=False)
    print(f"Wrote {args.output} shape={df_clean.shape}")

if __name__ == "__main__":
    main()
