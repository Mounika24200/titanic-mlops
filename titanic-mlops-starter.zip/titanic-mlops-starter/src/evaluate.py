import argparse, pandas as pd
from joblib import load
from sklearn.metrics import classification_report, roc_auc_score

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--model", required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.data)
    y = df['Survived']
    X = df.drop(columns=[c for c in ['Survived','PassengerId','Name','Ticket','Cabin'] if c in df.columns])

    model = load(args.model)
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(X)[:,1]
    else:
        import numpy as np
        score = model.decision_function(X)
        proba = 1/(1+np.exp(-score))
    pred = (proba >= 0.5).astype(int)

    print(classification_report(y, pred, digits=4))
    try:
        print("ROC AUC:", roc_auc_score(y, proba))
    except Exception:
        pass

if __name__ == "__main__":
    main()
