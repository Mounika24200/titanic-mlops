import argparse, os
import mlflow, mlflow.sklearn
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from joblib import dump

SEED = 42

def split_xy(df: pd.DataFrame):
    y = df['Survived'] if 'Survived' in df.columns else None
    X = df.drop(columns=[c for c in ['Survived','PassengerId','Name','Ticket','Cabin'] if c in df.columns])
    return X, y

def get_models():
    return {
        "logreg": Pipeline([("scaler", StandardScaler(with_mean=False)), ("clf", LogisticRegression(max_iter=200, random_state=SEED))]),
        "rf": RandomForestClassifier(n_estimators=300, random_state=SEED),
        "gb": GradientBoostingClassifier(random_state=SEED)
    }

def eval_and_log(y_true, y_prob, y_pred):
    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred),
        "f1": f1_score(y_true, y_pred),
        "roc_auc": roc_auc_score(y_true, y_prob)
    }
    for k, v in metrics.items():
        mlflow.log_metric(k, float(v))
    return metrics

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--registry", default="models")
    args = parser.parse_args()

    os.makedirs(args.registry, exist_ok=True)
    mlflow.set_tracking_uri("file://" + os.path.abspath("mlruns"))
    mlflow.set_experiment("titanic-classification")

    df = pd.read_csv(args.data)
    X, y = split_xy(df)
    Xtr, Xva, ytr, yva = train_test_split(X, y, test_size=0.2, random_state=SEED, stratify=y)

    best = {"name": None, "f1": -1.0, "model": None}

    for name, model in get_models().items():
        with mlflow.start_run(run_name=name):
            model.fit(Xtr, ytr)
            if hasattr(model, "predict_proba"):
                proba = model.predict_proba(Xva)[:,1]
            else:
                import numpy as np
                score = model.decision_function(Xva)
                proba = 1/(1+np.exp(-score))
            pred = (proba >= 0.5).astype(int)
            metrics = eval_and_log(yva, proba, pred)
            mlflow.sklearn.log_model(model, artifact_path="model")
            mlflow.log_params({"model": name})
            if metrics["f1"] > best["f1"]:
                best = {"name": name, "f1": metrics["f1"], "model": model}

    best_path = os.path.join(args.registry, "model.joblib")
    dump(best["model"], best_path)
    print(f"Saved best model '{best['name']}' F1={best['f1']:.3f} -> {best_path}")

if __name__ == "__main__":
    main()
