Place Titanic train.csv here (download from Kaggle). Then run prep_data.py.
