from pydantic import BaseModel, Field, field_validator

class TitanicFeatures(BaseModel):
    Pclass: int = Field(..., ge=1, le=3)
    Sex: str
    Age: float = Field(..., ge=0, le=100)
    SibSp: int = Field(..., ge=0)
    Parch: int = Field(..., ge=0)
    Fare: float = Field(..., ge=0)
    Embarked: str

    @field_validator("Sex")
    @classmethod
    def sex_valid(cls, v):
        v = v.lower()
        if v not in {"male", "female"}:
            raise ValueError("Sex must be 'male' or 'female'")
        return v

    @field_validator("Embarked")
    @classmethod
    def embarked_valid(cls, v):
        v = v.upper()
        if v not in {"C", "Q", "S", "CHERBOURG", "QUEENSTOWN", "SOUTHAMPTON"}:
            raise ValueError("Embarked must be C/Q/S")
        return v
