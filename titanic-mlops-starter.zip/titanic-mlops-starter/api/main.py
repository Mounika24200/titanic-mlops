import time, os, json, sqlite3
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from joblib import load
import pandas as pd
from .schemas import TitanicFeatures

app = FastAPI(title="Titanic Survival API", version="1.0.0")

MODEL_PATH = os.getenv("MODEL_PATH", "models/model.joblib")
DB_PATH = os.getenv("DB_PATH", "logs/predictions.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

def init_db():
    with sqlite3.connect(DB_PATH) as con:
        con.execute(
            "CREATE TABLE IF NOT EXISTS predictions("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "ts TEXT,features TEXT,prediction INTEGER,probability REAL,latency_ms REAL)"
        )
init_db()

_model = None

def load_model():
    global _model
    if _model is None:
        _model = load(MODEL_PATH)
    return _model

def to_features_df(x: TitanicFeatures) -> pd.DataFrame:
    d = x.model_dump()
    df = pd.DataFrame([d])
    df['Age_missing'] = 0
    df['IsChild'] = (df['Age'] < 16).astype(int)
    df['FamilySize'] = df['SibSp'] + df['Parch'] + 1
    df['Title'] = 'None'
    df = pd.get_dummies(df, columns=['Sex','Embarked','Title'], drop_first=True)
    return df

@app.get("/health")
def health():
    return {"status": "OK"}

@app.post("/predict")
def predict(payload: TitanicFeatures):
    started = time.perf_counter()
    model = load_model()
    X = to_features_df(payload)
    if hasattr(model, "feature_names_in_"):
        for col in model.feature_names_in_:
            if col not in X.columns:
                X[col] = 0
        X = X[model.feature_names_in_]
    if hasattr(model, "predict_proba"):
        proba = float(model.predict_proba(X)[:,1][0])
    else:
        import numpy as np
        score = float(model.decision_function(X)[0])
        proba = 1/(1+np.exp(-score))
    pred = int(proba >= 0.5)
    latency_ms = (time.perf_counter() - started) * 1000.0
    with sqlite3.connect(DB_PATH) as con:
        con.execute(
            "INSERT INTO predictions(ts,features,prediction,probability,latency_ms) "
            "VALUES(datetime('now'), ?, ?, ?, ?)",
            (json.dumps(payload.model_dump()), pred, proba, latency_ms)
        )
    return JSONResponse({"prediction": pred, "probability": proba, "latency_ms": latency_ms})

@app.get("/metrics")
def metrics():
    with sqlite3.connect(DB_PATH) as con:
        cur = con.execute("SELECT COUNT(1) FROM predictions")
        total = cur.fetchone()[0]
        cur = con.execute("SELECT AVG(latency_ms) FROM predictions")
        avg_lat = cur.fetchone()[0]
    return {"predictions_total": total, "latency_ms_avg": avg_lat}
