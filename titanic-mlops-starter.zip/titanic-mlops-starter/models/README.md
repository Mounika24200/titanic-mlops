Models saved here (model.joblib). This directory is produced by training.
